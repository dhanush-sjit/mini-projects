package com.mycompany.fishe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
