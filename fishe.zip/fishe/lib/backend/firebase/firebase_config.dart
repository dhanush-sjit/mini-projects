import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBx8j-jNJ5zi4w2nprMPyCwCzc618nI5J8",
            authDomain: "vegie-cc0b4.firebaseapp.com",
            projectId: "vegie-cc0b4",
            storageBucket: "vegie-cc0b4.appspot.com",
            messagingSenderId: "870635676441",
            appId: "1:870635676441:web:14cedacf95ba9f58225b88",
            measurementId: "G-ELKFJQJMPY"));
  } else {
    await Firebase.initializeApp();
  }
}
