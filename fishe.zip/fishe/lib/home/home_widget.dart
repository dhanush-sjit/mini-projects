import '/auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'home_model.dart';
export 'home_model.dart';

class HomeWidget extends StatefulWidget {
  const HomeWidget({Key? key}) : super(key: key);

  @override
  _HomeWidgetState createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {
  late HomeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomeModel());

    _model.searchFieldController ??= TextEditingController();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFFF1F4F8),
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text(
          'Home',
          style: FlutterFlowTheme.of(context).title1.override(
                fontFamily: 'Lexend Deca',
                color: Color(0xFF090F13),
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
        ),
        actions: [],
        centerTitle: false,
        elevation: 0.0,
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Material(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child: Container(
                    width: MediaQuery.of(context).size.width * 1.0,
                    height: 60.0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 5.0,
                          color: Color(0x430F1113),
                          offset: Offset(0.0, 2.0),
                        )
                      ],
                    ),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(20.0, 4.0, 20.0, 0.0),
                      child: TextFormField(
                        controller: _model.searchFieldController,
                        obscureText: false,
                        decoration: InputDecoration(
                          hintText: 'Search  here...',
                          hintStyle:
                              FlutterFlowTheme.of(context).bodyText2.override(
                                    fontFamily: 'Lexend Deca',
                                    color: Color(0xFF95A1AC),
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0xFFF1F4F8),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          prefixIcon: Icon(
                            Icons.search_rounded,
                            color: Color(0xFF95A1AC),
                            size: 24.0,
                          ),
                        ),
                        style: FlutterFlowTheme.of(context).bodyText1.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFF090F13),
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                            ),
                        maxLines: null,
                        validator: _model.searchFieldControllerValidator
                            .asValidator(context),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(20.0, 12.0, 20.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Admin actions',
                    style: FlutterFlowTheme.of(context).bodyText2.override(
                          fontFamily: 'Lexend Deca',
                          color: Color(0xFF95A1AC),
                          fontSize: 14.0,
                          fontWeight: FontWeight.normal,
                        ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 1.0, 0.0),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 8.0, 0.0, 8.0),
                      child: Material(
                        color: Colors.transparent,
                        elevation: 2.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Container(
                          width: 100.0,
                          height: 100.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 48.0,
                                height: 48.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF1F4F8),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.admin_panel_settings,
                                  color: Color(0xFF95A1AC),
                                  size: 32.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 8.0, 0.0, 0.0),
                                child: Text(
                                  'Dashboard',
                                  textAlign: TextAlign.center,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyText2
                                      .override(
                                        fontFamily: 'Lexend Deca',
                                        color: Color(0xFF95A1AC),
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 0.0, 8.0),
                      child: Material(
                        color: Colors.transparent,
                        elevation: 2.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Container(
                          width: 100.0,
                          height: 100.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 48.0,
                                height: 48.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF1F4F8),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.directions_boat_sharp,
                                  color: Color(0xFF95A1AC),
                                  size: 32.0,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 8.0, 0.0, 0.0),
                                child: Text(
                                  'Boat lists',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyText2
                                      .override(
                                        fontFamily: 'Lexend Deca',
                                        color: Color(0xFF95A1AC),
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 0.0, 0.0),
                      child: Material(
                        color: Colors.transparent,
                        elevation: 2.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Container(
                          width: 100.0,
                          height: 100.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          child: InkWell(
                            onTap: () async {
                              context.pushNamed('sheet');
                            },
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 48.0,
                                  height: 48.0,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFF1F4F8),
                                    shape: BoxShape.circle,
                                  ),
                                  child: InkWell(
                                    onTap: () async {
                                      if (currentUserEmailVerified) {
                                        context.pushNamed('sheet');
                                      } else {
                                        context.safePop();
                                      }
                                    },
                                    child: FaIcon(
                                      FontAwesomeIcons.addressBook,
                                      color: Color(0xFF95A1AC),
                                      size: 32.0,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 8.0, 0.0, 0.0),
                                  child: Text(
                                    'E-logbook',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyText2
                                        .override(
                                          fontFamily: 'Lexend Deca',
                                          color: Color(0xFF8B97A2),
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.normal,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(20.0, 8.0, 20.0, 8.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Previous Auctions List',
                    style: FlutterFlowTheme.of(context).bodyText2.override(
                          fontFamily: 'Lexend Deca',
                          color: Color(0xFF95A1AC),
                          fontSize: 14.0,
                          fontWeight: FontWeight.normal,
                        ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 50.0),
              child: ListView(
                padding: EdgeInsets.zero,
                primary: false,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                children: [
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 8.0, 16.0, 0.0),
                    child: Container(
                      width: double.infinity,
                      height: 200.0,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        image: DecorationImage(
                          fit: BoxFit.fitWidth,
                          image: Image.network(
                            'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCAEOAU4DASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAABAUDBgABAgcI/8QARBAAAgEDAwIFAgQEAwYFAgcAAQIDAAQRBRIhMUEGEyJRYXGBFDKRoRUjQrFScsEWJDNi0fAHU5Lh8UOiFyVEgoOTsv/EABkBAAMBAQEAAAAAAAAAAAAAAAABAwIEBf/EACkRAAICAgICAwEAAgEFAAAAAAABAhEDIRIxE0EEIlEyBRQjM0JxgaH/2gAMAwEAAhEDEQA/AKpb3LSSKGbj9KsSQxSQjDc4qmCRgRjtTmw1BgAr9OlImES/i7eQ+XyvyBXH4u5d8P8Am7cU3FxZshJxnHelUskRnBUd+1IKDUinZASDyKEuLaQZPP6UyjvYY0UMR2rGureTOMGgYhbeoxUYZgeabyQxyHgfpQk1qyZ4pMKIVk6UTBInrz8UCY2BHIGSBk9Bz1NGyRSbU2gFlkdQ2YQWjCjBCw8BfbNZe1RpaA9St3nQKP8AFmkp065GMCrQijA3jnv8VMBDjGBSjHiUlLls58IWXkztLKxEmcAZ4xXp8MzxbHXnHb4615tDL5Do6cEHtVjh1lhH6ueOKlNPsvFxqi+wX9rOOH2uOqtwwoa7iikkE2TlTkEHHSqFJrgVwR6T2IPIpna+I4ym2Uh8dDnBoWd19kLxK7RcFvoEXDt05HTgfNVjXJIdRdRz5ce/b8ljyaUX+vW+SVYD4pU+uCQhVkx9qlkzyapF8eBXbHNuI4MBTjFMhqC4xmq9bzh8M7A0a80RiOCD6Nw5QYbcOB/XmuB29nXaT4jyK6BGd4HxW2m3EENVLn1N7ZuWOM+/SjrLWonC72x9atGTaMSikywzGR1ZQxGemKGgGoW7k7wy9QAOa7t7xJ3SNCrFsAU2FpgEk84ycVaGNP7EZZWvqDreSuAGP1XAHNGBBsBJO44NCNFHjPf4qZJTtA4OMDJqqkk6ZN21o6AZm2k1j22QT3FcZIYnPqJqQXGOG6VOUogov0AsGDhSea6aNGPJwfc0PeStvXZ79RRdsplXBOSNuRxnHzmpxipMs5tKzlFCgjPbt3om3vIoR5chYD+lgpI++KGuoZLZfMTmI53D/Dz1oRblT25+aTk8cqQ0lkjYyubqCUrtYttPXBA/Q1E0gOBkbSOaClAfbg4LcHFGJYQiIDksw5bPU/HNUjymxS4xWjj0rzu4rpJEJODnFVzUb64sp3t2PGAyMe6n3qO31GQkesViVxY4NSLS4D9zx9KY6fKI1y79e3FIre6V1ySCfrXcmpQ2+NzAD45qsZU7J5FyXEtqTwyHareo84qTOKrGjXy3lzK8bZ2YXb2AJ4qzn8p+lduOXJHDOPF0bzWCo06mpKoYPmsW8u78p45NE29tIzZGfarJLBZIhK46e1LI5Yoi2MdTSMG1s5WIUFuaNjsVhyz9cd6hi1GFGY8Y6DNRXeq+aCqY/SgNEd40ZAVeoNQxnHIOPvQ4Jdxk/NTsECjH6VkEMYLlFGCR961Pc7umCPilqEUQGGO1KxnaIHJbj6UUu1AMcHFCo3t1qTe5PNA0csS7Ec8nqakKqg46gdc13sG3nnvQzvJkA8jPYdvmgdBcKM5GBnNM1tGVOR+YUHYyxqRuxToXMJUKMGsSVm0xBc27FuByKHFnc4yhYfrVi8qNyW+akWJFHSsKJSymXFhenJy2fvQlvb3SygNnrV/aCNhyoP25oKfT1z5iKMjmtcUHJieSZ4IsKcN0qK3u2ByzZJPNavobgMxCnnrQsMTsSDkDv75qEsaeiiyNBlwrXjbVGR7+9at7Z0JVgRgZHWmulQRjKkeskbfpTmTTTKBsjG7B5+K2oJKhc23Yu0kTxXEMsZP8tw2CeCOhFW+TVI0TB3BmBX1cAZHeq3DCbJz5jf8AvS/WtUUKQjcjpg1Pa1Eskntlga/dySG+wrG1BokyWyTiqJDrcwIDcnj61O2ryStGmCFzkk1zvFK7ZbyR6Rco9SlY7iDtFbOpo7bVOScDH1pD+PiSA4IyRgdM5ozRLfznMr43E5GewrCTb2afFLRYktmaMOeSQDioluWhlUqcMpxj3+tMWniij9RA2r7gZqq3N8n4wuD6S4z7VfJCo3EljlbqRc0linhBKgh1wwPT6UvltYUPA9Iz9vrRWnyW88COhBDLhvrSjX5ZbOJ2T1DHp5/Wr7kroi/q6NtLBHnDKMHoSK2dUCKVVxjBxnHFebXWuXe/DOMc4xQD6zeMeZn9gATisrHJbQ3lj0Xu78i6lMkmWYgeo81JbaZBPCXGec4244xXnzalOwwJZBnHRjV78GNLcWrpvJYyFuTn09KOMn2FxS0FW+mX4cok2OcZPt9KOfwzdyozyXLNJ1UY9OPgU9g064EgbGckE+1Ooo9igMBu/wBKtGFvZBypFZ0HTWsMocecZCzHn1e2M1ax0GetQtFGrrKByDg49jU9WjGiUnZlZzWVlbMngMc0smQzk+woe5RlOB1xz964DhHY4OD0xW5Jw/GOB3PekTBdrdcmuhke+TXRYciukILD1IOMkyMFXj5pASJFIcE5AroqwbBNdu5jJQgduhyCCMgg1yJB3pDNlCADWLz71vzdwxjtiuPUvXpSGiVC2eOgohS2cUKrj9a7WTJ60DD0J4BNSCJWbkUIrHjJo6Jkbbng0DIpYWTlD9cVtJZ0weg4oiUkDO3itFfMTg+oDpQAVDeLgZIz3plBIjruIBz+1VowygbldDgjIVslc9NwFGQ3DIAdxHGCDRoeywKru2EGT/attGRkOpB+aFsb0xn1ZIYjkYJH2pys1vMMAq+ex6/vSo0mJZ7NJBjAH6UGulqrEgcVZzZxurMp2nt3FCPE8Z2uPoex+lY4mrsGs7aOJlJA6YpukqIHU9+hHNAAAGpAQK0gQn1n8RcFUt1YYPqY8Z+MUnbRLuYDezEt1OOlXAojHkdwaIAjwuNoFFIeyp2/hMIod2yTz06Vkug5DALyvAIq1JdsUfEKnYGJ/mDdhepC4zUtqI5iGYYBXcR98YpUB5/JpF/Gw3A7Qc4pjbahJp64ZSAAOauV1bw7dyjvjBpPdaKtyp4ABqMoq6NKTQmm1prgbd2AeuDyfrmltxexoC7Oo44Gc/pVqsvDGnpETMpklbcCSeEH/KPelGpeEkzI0DuWGSN3b4p8CkchDofiF4JljL4ikIBB6Vc72MajaOmOHT0kdMkV5YLO70u6ieeJ3jWRWfAJ9Oa9X0nUtMubaF4542UgenIDD7Gnjg4hknGZ5jd+EdcLOwAIDHg8ZHuKUS6Hq0JKvCeP++K9yuJtPI9LFvhQf9aAltbW4w+zBI6EckVV5KOZYm+jxP8Ah9+DjyZD9FY8e/Ar0r/w7sL6CO7lnRxHLIixqy4xtz6hnmrZDa6esKiSJRgYDEDge2RUsEsFqw8kkrnn2/6UcrGoOLHw6ADtWUINRsxtEjiMkZG8gA/Q0Qs0L52up+hGD9KpaMUyQjNYOABWsj3H61rcoODx/anYjqsrK0WA68fU0WB86bZQvmBW2+4HFcZ3dOueP7Uwe+iMDIN2Su0DbwP1pYCVYMOcdqZM7eOROSOD3+a7gk8li20kmNkBVtrqW/qRsHB+1Y829AMYx1+aiUgGsgTzStNIZCpXcEzuYscqoXJJ+lcZFbLbsDHFcjgmkMkVsY/SpT81Cvapmxt6nNIZy3asDGuRyakA5H+tABEbZ6+1SCfawx9KFYkdMcVpWI5pDHEU+8BSM/Jonyi65Q4NJ4bkIQCKapOQoZeQeaDWjuV59mxkP/0/68opj7omMc/WohE0isT0HYcGiBdI2A45PTiplVTyrfXPSlRqrFiyzQOQckDkGmlrfIxXJ5/eteTE+dy89c1G1gFO6POevFMVFgt750AyQyccHt9DU006SAkHk+4xiq9C86YVwc5475xTBJlbg5BoNILGPetjHaolOelSoQOvegZ0DXW5R1rrarcisjhZ2xkAdz8UhkUTSpG8exDu80EiRhkSDb6lHBx2/wDepYN6pGA2GUdR9a08XlnGcjscVNAYgDuwD7t/pRYHe6RmXe+frx+1FKVxg4+1Buyg8Y+oray8jPT4rPEAplwDtO3I7cVCDxhju9ye9du4YAZJrjCitGkDXFla3HDovIqK00m3t3JjVQDyQBjNHkLWZI6UgA9QeW0jEqRsyqRuC9cVPZX0NxErDAOO/Wp2MckZSQZ/elAt5IZHaLKxsTgYqGTG5O0WjkrTHBmAztGcjnPStx3CElZI4lycqSNwz96WxLLuyWbnqM8YplbweZu4BK44PsapBUqJN27JDLlTDNDbSwN/lx+/INRJcNauxWJvJzgDO5lHwa6MKKzK/GD0xxUnlIV9K5HB4PH6VsyS299BLLsDSAnnD+nH0pklxGh2v7deCf8ArSs28HlvMu0SKDyOOAM96pOjeJ77VvEkunRRiSyjEoDPuVgqHG4nnnPArUf0w66PUkkSQZU5oa8tJbny/LmKbc5A6HNZHGY8FAQQcEdQR8VKZ3QAtG3OelaTvsy1vR865/SpMKBnHNN7uxi8rTpfNikDQmBpYDlXMBwpIxkEqVyCO36rJkSN8Kcjrz2+K2RIMEnHY10qAtj3rWTjpWh75pAEbEjwc9a0QnUVGAzEc55ondCsezjdj75pUBBkdK6CyH+lj9AeK4QhXBIzgg4ppHqFukWwqc85IUHPxSGgCNgjc+9Hutu65zzgEGgWZWYtg5ZvSAMkn2wKeaZ4X1rUsPIFsbfGQ9wGMj/5Ihz+pFI0k30J9qhiDz7Cu/KcjIAxVxg8JaRDn8TqMshB9QBRP7c00g07wzagbLEzkdWZHkGBxkluKk8iWi6wT7PNwEY7QMt8c/2o6IzBcLFK2OAQjkY+wr1KFtMhAEenRx8DG2GNe3612LkuCI7XC5xwoIH6DFLyDWFnlgZgfWGUZ/qVhj9RRcUu1TtbI9ia9JBtyMSQRlSQCXUFee2elD3Gi+G73O+3t45Om+EmJgfkpitKVmZQr2UqGdW4PBxRSvyNoz8U5Pg+xyTDq0qj+lXiR8Z7ZyDWN4RvlAMGp2745CyROmfjKsf7Vq0Z37FsSl2ICEEjvXEsMkcgOPT9etFtpHiCxcM9q0seeHtmEuPqvDftXX4bWJX9NhMwxkgrtI+zmjQEKbsZxx355qSe+sLRYzNyp6AZJ/QUYthqzDC2LgBR6iETGf8AMaV6xoetXUA8myYyJ/SjxZPz+asTdLRfAouaU+ix2Z0LULYNblcsvYncPqM5qW10YDeFuWBJJGPVjPuDXmotPFelMkh06/jVT6isZkTb8mImrdpHiOytEJnlbzpSpdZt2c49mOaIT5K5IvkxJag9jibR9QTLZWcdvLwrf+k8fvQb21yoOVwR1Vjhv0NP4NWhuUR4wCDz1/sanM1lcDZInx/MTv8ADVROL6ONqUe0VTJ9sfFTpETz6iMDoOKczaHbOGaCR42JJGfUvP70I1nqkYKrAZAowpjkQBvkAnNHFhyTBWt5VGQeMZ5qa3t/MOW6Dpk4zWt94AEmtpoh0JZTt+zdKMhtEdQ6TMM9d2GFIDlrSMjC+lvg9aCaKRCwYHrRUiy28gYSAox25IONx6BucjNcszPIgZQNyBsbgRkek8inQ0yOJUOQ3Ue3WskjBdUQMS3QY5X5JriUYcYwPcA/61JEzq28HIA2tzz+tIZkluU64HHBz1NS20c3m5UHBUA4571IJ7efKPhWUYXHJHyaJtYGtHkldg8bIoVl6rk9xTSE3QtuhcCdwQd21RjOAfnBriA3uZdgbEf5gVJGPk9M0dfSxvcJIqllSPaWzgE5zj7UXbXdkIgikBuS0aqSST1+P3opWK3QqTUIiHSZSAQQHQAgH3xSPSNM0nRNS1C4LMPxzjy5mUhOTnB9uacy2Rw7gMCzMwB6KCc4rQtzcQPbzxrhhjeOo9qSdDcfYwh1AM7QjJA6FcEH5DCh9S1N4GjTr1PGAe3Wk6/xbSSzyw/iLeL8stv/AMUqP8Se9K77xDBqc6ywJNHGkYUedE0ZJBOT6hTRiXRSXlQQ+SiqFM7XDMucligjCjtgCoVRWPJrcaqeB1z2NTrHApO8jNVIAroE4Bz81pYgyFs89qlcKpIGdpyBXAC+obuMdKAI1YL9a7A3NnpxmtKEG7djPatIwLjJwppAdybMcYz9K6hgmuHWOJSzHHHtnjJoiKya6kWOBWyQMsc4Aq22Gn22nwqTjI5d296jOajsvjxyn0SaHosOnFLllEt0RgFgCEJ/wZ6fWmOpahZW3qvJZH/mMpt7QuoYgA4eQ/6VXNU1u4KvBbCSOAZDMvDP9T7VWpbtyrM8rejH5mJ6cdTXG/k3pHr4PgOuWTS/C7L4zjgIFppFnGi8DcGZuPdqn/8AxBuRwdOtDkYADOK8+S6BALEsGHBFdCaEHJ3D2yOM0lOf6dEvjYl/2l8fx5fbty2VkDgDkOcfqa3/ALf6plf92s9oHI2yc/vVCM8eTgkcc7s4FYJkIOMEYyTkj9KPJP8ATP8Ar4vwvknj6/ddotbMA9AUdgD74LVH/tpdkEm1sucZCRYOP82TVHWVCQM7hjPDYx+td+YjEDLL9f8AqKHkm/Yf6+Jei9QeMpjIS8UQUngBentyOTT+y8S2E6qJVjBJ59OD+oryoCQAkc47g5H6iiIrh0IwSDkDI/vQss0Zl8bHJdHs0F7YS4EUrAtkDDb169ieK6kMzc+Wk6AYzGdkpOecAnH715bZap5JYOZhuaP1RFcqoOTwev0yKteleIGJxL6jtzjPU9BkVaOa9SOLJ8TjuI8kgvZvVZ3TOq8Pb3BKupHX1f8AUUMtxewkpIrRuOMMpGcdwTTSKax1EA7SJEOQQxWRSO6smDWpkCkpdyiW2YDaXUiWNhwAGjHIPc8VZQXZy8mvqQJqUwwDGjccnkZrbXFlOCLiyicEn80aNn/1CuLmyeD+bBukgxuKj1Oo9x7ihVlDD0FSfr296dpaYl+ol/hWhSNvt/NtJCf/ANPIUXJ5/Icp+1TJZ6jCknlzx3SFT5e9Qknxk8qf0FQlgFQ9B7/NExTSqFUyZyAF6DjrjinxT7HzkvZ53qviLxloshW+tZ4oPNYqZVZoSpPRZU9H70w0vxrGzCSe7ufWoCw7VeIf5TjP71fTMsitHPGkkbjaysqspB6hlbiq9qHgvwtfb5bWM2FyeQ9mQsZY92gb0foBU5YmtxZ0R+RF/WcVQ6stZsL1EPmKpkGUVur87TgfWu5LKxlYyxjypPUvmW77fV8gek/pVFuPDOvaYgSKV7y0dsmS3TbPaTf0zrHkkoejjJ96J03xGIGFvKJBJEEgmRyCkbR8Hb/Ucnnmn5XH/qIy8ClvE7LTJpt1uLpMJ9ygOs3pDdiRjjJ/0pe6yWx2spQKzAiRcD1Y6fH3ptZ6xY3SjDBSR25Wj2SGdCrBZI2HRgCDVIyjNXFnPJSxupIqxIZ1Zjxnntx7UXviwmx8H/kx+9E3OjnBa1f3PlSHI+it1/WlbRTxNskQo3+E9f2pNNGk0ycrbElmJ39m75+1aQXkhKCUmMH0g5BFcrGpUnJDDrkj+3WuvNnjB2xS9sELlf1osKObmW4tELy5Kf1Ec4HvjFV6/wDFmmWgJE5Z8fliBB+/FWkH8TERID7cgZH2NUHxH4QNzJNc2jsHIyVxxU5RsafEHbx9ITkROyg8eZIeB9q1/t9esVWOODLsqDcWPLEAciq3HZR2JMF/Fgg4DEek/ejYl0KHDqqfZBnn61J0uy0drRa7fxPqs4GYGdGlmiYxxTqmU2n0GXk9TzWtQ12zkWCKa1uBJDuyPQRg/UA0mi8R2kAVFjyFIAZ5MnH0/wDeor7Ube8kSaOPHp2nJ4P61hSkncGE+L1JClSrONnGOaz/AIkhUtjA6ioUWUSeWq5cnGBwQfnNWHS9O0y2dbnVVFwRhkt8+jPX1DvXfKairZx48U8jqKFUFlqd85SxtLm728FoI2Kj6ufR+9MF8JeLXGRppTP/AJk0Kn9N1W+PxdHCEit7WKKFPSFUAAD6LgU0t/FlpcAJMir2+frUlnT6Ol/CnHs87m8JeLYVLNprOB/5MsUjD7A5oO003WXuVSLTLySWJxvRoWQD/Mz4X969kj2XaCa0vTGRzsJVh+jUJPPHHFNDNqFvC7gjzQ48xT7gA0PI16Mx+Mpeyv2mm3UEEUt+YrYhf63U7fqRxS7WNWsLaPyLdvPujwS35F+cVFqf8GhkWa41nUNWkDemDKxxAf8AM4H+lLhd6MxdpNFhfc24bZ51bZ/h3A5xXNkip9s9P4z8bX1EVxdyyljK5Oemen2FAtPEvpcEqSCQelWC4FlKg/D6VbW4XeSU82SR8/4jITRumeEbXW4DO8qWkAdVE0Q3ys4/OqofTj60Y4JUqK58rcW2ytBopMbXUAKPzcYPsKlhjDT28Uebkyuq+THu3MSfyjHNek2ngfwTawoDbzXkxX1yXs0vGOOFj2rz9KNXwf4eiK3ml/7hdQHKSiYmJWx0Ik96rKFqkRxfMUP6K23hfTrkyJbpPbSIq/y5X3jeV5GTzVcvdD1a1dlWIyqmeYyrEfbOasGoa5rmlzzo0lrO29gwKBgxHs60mj8Qy393bpKnkM8sayYPpKlgDgmoRh6Zt59WhCwnjZleKRWX8ysjAj61H54Q4J/WvUW0e0mVWIwH5OD6m+fagpPB2n3Jbyzs4JO5i3z3NU8Vq1slH5qemUSC6CkbWIx3U/3FMYriKTjIPH51HI+q1LqvhC8sHzbTwyIcnapK4/uM/eq+/wCLtJCkylWXqealXpF1NS2WHAGCOnTcp6/UURFcPHgq3PbnFJINQYDDFSre4zn70ck8MnQ7ffB4zWXEqmWfTtVvEmVhK248Ahtu33q32Or213BJbXe9iwIymA209cYNeYrI0WwhgQcHIyc/pTK31MJNAkT7fUAWbBDZI555rUJyg9EMuGORUeoWV0cGERoY48BGikD7U6DI6/eor+wC7ri3T3eaMf8A+lA/elGk69C8d5JKd34SOTCxqpkcou4rkDPPamWmeI9K1U7beULcH1G3nIV+BnKsuVP613RfNb9Hjzi8b/8AIMskEkYAYbWUjKsGHqGMiiEWFUjVCSsSKuTy3tk0r1fw9pnmyajFC6iR83USvIoRyceYoU4APfHfnvWW9nYRp6DMvThZnbH/AKiay5cXTNqCatMc+ZhQA2TW1kDY3DB6UH+FuAqmCZyeuydcgj/MoqN5J4FL3MLCNeTJDmRQPdgvP7U79oXCxssjqQQwIGMjk5xxUN7p+jamv++2qF8YWaP0TL9HX1f3pbDqlpOAbW6tpfjzFz/fP7UdBeI5COAG/wALcEj/AJT0NLyp6khrDNbiJ28Oahp7mXT5vxdsesbFVuFHweFP7UdY6hNGRG5ZWHBR1KsMe6tzTMSGIjaSoIyh9xXFzBaX6YmG2UD0TR+l1+/f6Vh4Unyho355TXHJsKS7hmA3EqwOcgmpf5FwNrAEj9R8g1W5PPsJFSXo3EUmPTJ8H5o+G4Y7SCQ3f5HvWFnaf2QpYKVx6MutKmDvNFMSMZVSoJH+Y+1Dm8v7dYxJbwshOC0bsTx8Hin0Mm9QW64+KEn06OSRpd7FTz5ZG5R77RXSqltEE2tMXFnu8PCgRsdHGefgih5meIiN19XPJORz7VFNI1tNLGjvGN2QUOD7Vwrec4NxK2zoGYgfbNI2jLvTNKvLV4rq1VmdSA4hYkEjqHAqjX3gG5GWtJ5VTnCyKenbmvSPxUkAVLZY50zj1O2fsRXMl5c3ICNbLFt6kPuP7jvQxWeV2/gq/WQG4l3DIAABx+hp6vhOEYDuRgDqc/2q5LIEDRum4HGGBGQfvQ8iy7zuBwR6cDtWaNUUvxBqOjCdI9OgRvK3BpVUDJ+vU1XvxsrNkgkZ4GaVDUI3xu4zyTVp0+28MT6FcTMlw+rNK4hb+btVcjbjpHjGc8GudwnLcj1Y5sOKo4wSO4V++DjoalErLgjJ9sdaBdFjPrXbj+oV2r4aM53xh1ZgGxuUHkZ+RxXOls7JSTQ1N5fQ4QrNGzLkbtykjOKHd5iGklcgM3JJ5NaubuKX8OsMbDy2mAURxxg+Y+5VVYyeR0569e9XHQtGitAlzcqs16AHUuAUgz/gU8bvmrRhydI5p5Y4o3JbKsmka1dKjWel306N/UIWVT8hpNo/ep/9nPGKqCukSjOceZLbg/pvr0M3eornbK5B4wcHA+9b/icg4m3Y6ZB/eujhR57+VJu6PJb3R/GcAeSTS77aowWi2uoH/wDGTV48N+WmgaSgLBhG/nBhh1n3kyBx1BzTmfXorfMaqsoIPoYHJzyBxzVdk16NL65a5hjghuTHKwijZVDouzec8kkfmNZ5RWrNNyy+h3Lfw5dHkKMoCgDgcHtjmpIrkzMXE15mBTIhJhFrCMYCyh15DH3Of0qp3Gp2Mt25iw6bOqtmMnJPbmlusa87WptrdYYIdwIhtlaMOwGN77iWJ9snioQzNun6OzL8dKFr2C+IroTX90skySGNjHmPaF5GcDbxxVWluTFIjpwyEMufccisNzb7087zPLMo87yyBLtzzsLcZouGyiS6kR1S5VozdW08wf8ACfgEVnkuCkbBy3G0Lxg5+3XCPs82U/R7FpkyXmnabdgYFzaxzqmSsjAorYHHSjYyi+VxlDlRgjzEzwUJ7jnvVa8MSqdLt4FaXZbtvslmP+8QW8p81IZuT0ydh9sVYsDcGIHXccDAyfpRjSi2kc3TB57aEEjBOCRkjgkEjvS+90fTr6H+bBGWztJCjI7cGnxwVK84HHTHfPFCgbZJ485DgMODXnuDx5X+M9SE+Uddo8j13Q7vSHeaHL2pbnjmPn+1K4L0kqM4PzXr1/axXMU8ckYKSKyMp5BBGOleP3lgbK/vLRgSIZML7lG9Sn9DXTCpKmbcpRproaR3Lbch/wApBwT7ntU5uxndtB6bip2kAfHvSdIZlGU3EAH09Tiuiz+lQME/4jwfvQog8ldlh028ljuGME+RJjchIVxjocVetDms7m6tzLb2ouUJ8ucRKk4B9JG9OuR7ivK4VfeMjnqD1H2NPbPUbiCSMq3qUjGSQePnrU5TcJFcWBZoPZ7epjKiOR1cMpjYMPzdRhs9/eq/cRfw64aBM+WRvhLYJ2f4c/HSkGn61J6GcN5pYk4wysTwDljxVnvCmpWMcoZfOt0/EIVJAYKMPgnsRz9q6PLDItdnHl+JP47uXTN295JG+7CsO6liBg+xp1GY5UDhACRg4wf3FVS2mTIBZRxyQetWHT7i3cNEkis6gM6odyoD0yw4yfaninumcuWGuSPPvHnh+3s5E1WyYQfiWYSxphFEqjJdQOOe/wA/WqRb+JNas2VfxJljU5AZgSv0Jr2rXtK/jAsUEcbJC0rF5CFClgF43A5/Sl8fhLQ40xdrE/HqAt4iAB2Lbf8ASlOHKWkdWH5XCC5MUaB4oh1uA224C+jBYwlgPNAHJiz/AFe4pta6tazu0SuUljO1439LqemCp5qdfBnhXKyQ2ohlRtyTQYikVhyCGXis1TwjbamsLi/ngvogAt3GkfmOAMYkUYBo4ZF0Dy4Ju5aD/MhuY/JnAIY+k4zz2IoFzJaSiJhxj0PjII+aEXRvF2mgfh7u01OFcZjmVrWc4/wnLJ+4o1blZY44b+2ns5uii6UBN3ssqkxn/wBVYnFtb0xJQX8ytEgvhEF3b2bdjCYIPHfmmcF9HI6Qskiu3IDgAdM+9V2eOSDYzgOFmU7UyDs+vzRMN0WntmWNgse8ElUUYLFhhUPzj/5rOOTjtkcuO39SXVraC2minZGaGZyJcf0t7cc4NQrd+HiDH5TjoAfJcD65zmnpW2voDHKoZTjcM4OR3BpfLoMJIMErouR6G9Qx7Butdf8AStHOm1pkNsbTLFGzz6e3H3rYlmQSo0avvJKsuMAfOea6GmPE0myJwV/Kysp38fPNQmK5iR/Qynqd+afQWmcSzW1sPMu9kcPUsTgA/elFzremXh32Vyvlxs0ZLbVyR7BiDilfi3Tdavoo5LaWWSCIFpbYZCkgZzwKpVhb6zqRnjt4GhW1YK3mLtJY5yPV7UUJvRH4W8OR6tPPPdbvwVqwG0cea/XBPsO9Xi6t7S3j8uCJERRhVA4AHFa8KwJDodqV4aYySv8A5mY0VdwwFJN6yOWVgPVgA9jUst1SLYmrtlTvbcvGzEZ56iq1NK9u5VSfoat7lIo2ik34XPqyMY+an0zwta3cou9WQ+UQHt7QMV3jqGuCMHHsMioqNHWsr9CXwk6X1/JNKjslkqyKoBYNIx2gnHHFei29xE7PtfEgLM0bcE/TNH2NzFZqIrS2t44AoVY4o1SMYHUKgFTzoL0AyAKPzHYoXBxjIPWuiMKWjlyZHN/YFEuQNpBB4PvWPEr87eD7ikl/LcaNIzzl5LQHf5igl4065YdwO9NrTU7G9iV7aaORWAwY2DAVmDbdMxJUrRnkJFucIu7aQTjkj2qv6rYfiFY5HOSBxnnjtzVsYI8bqD/Sc5IHQZJzQH4cEKWUYGCc88HpyKJ401SRTFl4nll7pdxbM7M7owbKAEhh85FJr2LVQnmytMyEdXO4gfJ64r1TWdNWYo3JYKVXaN2R07VUbjStOhkubl1nBMThtsmF3Yx6laoRfDs6nHyR0yuaHK/nPDEuJmV5g8ZAuJhEpYWsLPkDcevGTjHwXQcRsqxFIpgyXOyJiE0+8cDzkt3ycow/MvQEdTiqlMgWWQJnaGO36U10p1ldY3dFOPT5hIUkdBkCuyTtWjhhGpUy/wDho3K3l00hMkd9CrCYkndNDyMn5BI+wq5K2RjuACc+xrzG1sr6G8t79LmQyW8gPl78Bsf0kg42favTYJY5Y0ZTnKI498N71z8q3+G8kHF2SA/POO1RP1UgjuCMYwfrXY4J61uQZHzyMf8ASo/I7UkXwMEfnIJHx2I+9eb+LrYQaja3KjHnI8Tn3aNsg9e4I/SvSnzhSfv9qpvjqA/w+K5A5guomPuFlVkP+lSxt86PQpOFlesGiYrkLg4BBH5T70+TSdMusiaFAzfmKEqD88VULSY+kg8VZrK83Kqk8jhT3PxVradMlKCatE7eE4VJa2u5UHXy5QHX7EYNA3uh61DteKBbiKMZzat/NHvmNuT9iaslrequ1ZD7AN7MffNWC1VjteRVwpBCsOOuAWHtTT5aJrI8Tspuj6L4j1KMyqiWVsCFEuorLGze5ijA3tj6Cr1pejy2UaJJeST+l1LyDyY/5vDbEBLc/Jqc3Me7c7MznHOe3x24rhrwkHH5ehwex5x9jyKmseODv2PL83NnXF6QUlno8IAW2gIG31PuJb2xvyxzjrmiUmtYv+AiJnPpjXAcHkHjv2+1KDcMxILdcnp3PUj+9clyOSxweOcc5rXlfaRzeK9Njdr4nOD6sZBOMZ6jv3H71H/EJB1yemSex6gn4PQ0r8wd8ggE9Rj6VKjAgZyM7sg9OaFlmxvDFDNL6Jo3QBVYkFPUSozzz9+PvU/4yMBSoO4HY4z+XI4+2eP/AJpIWC/l68ZAwMjPIogOR6kLAjaGU4JIxjr+xqiyzaJPFH0Nku4s482I7sHl1BGTjoamysi4/ltGRhlbayn/AEpMJI5Qd2BwThlGTn5qeGHao8uRVWTJIzkZ6045n00TliS2iS4g04Ahx5ILbQUyUz8rS+fS7mH+ZAS8fLYiy3/2jn9KPljuzE0atBIUySG8zcQOQOp696jtLq4jVopoDEoRGz5m5SG7KcAgisOm/sisJyjHTsitbgQGMmeBw45RH9at0Kspwc/apNVS6ubf8TptzLFdwqdoRyFlXqUYdM+1bdrW4RVmtIZmX83mIN/OehHNQh47Ygx2hSNvyPHO7Rn4II4NUhcf5ejMkpbopp8Z67au0ckysyMUdLiJSQw7HGD+9Fwf+IEcytDqFrGARgS25Iwfco5P7Gj9U8K+F9fuWu7ie+tbt0AlazmCByvQspUgmlEn/hbob8w6/qKk/wDmiB/1wFqy5fpluFVxL5p76Ve2iyWU0ciTRrvaN8tnjIcZ6/atfwewRnKxEBuTsIBz88V5/F/4Y6hbuGsvFMyc8bIjG36pJVjsPD/iyyRoz4mvJhgAb/Jfb/8A2oT+9V0c9P0Vfw5cqdLSLDLNbvJHLG4KujhjwVPNSXsjhGZmyc8DPAFW4tpt7hbyOITFQsdyAEbB7Nt5qq+JNLvtPhadSZLUcngZAPfPtUZb2dOKumLLNDczvJMF8mLBjUj87+5+BVijkabad2MDBY+wqvWp2KI2b8uQxGT6vnFOoGkwiqyA5XDAE+jvge9czlR2OFDSAfzFUEgFgOvP2FOkRtoU5A55GOfrSq2VARubGSC3IHT/AJjzTOOVGBOBweME4wa68crR5+RNAWsWaTwHABZVb5BBGCK8n/BXGmX1x+Dmlgw+9DGxACtztx0P6V7HKCy7T0IOMfpXmviEC2vGXozRhh9NzDNYk6ZqG1Rq28W6hbZjuo47gBSrMo8t+Rj1D8ppzaeKtMuCqm4SJhgeXPhMDpjnj9686urpVfAyZGIAA5Yk8AAVkenz6jcRW1oNsnmSLctJIsywIgUl5GRQAecYGa0tmXp6PWZry3kAKlGyAVKMpB+4NVrxB+F/CzPu2uVIBJ2+ogn70JbaNp9lAY4/Odz+eSVyCzfABwKDvNPs3G4vKWHAy27H0zxXPkknqjvwJw+xVfw7kbtjENk9DyOlQhDC47AnvwQasyQlFADcAD84GT9qW3wBLYAx0P1rcWScLlYzsrsyhMth1UKdx9LHHGau/h25ldZY5V2qhHk54JDrvZcew6ivJhdeSvG9WAxwchu1XHTJtZkt/MbbaB/w8ql8vMHhTYHC8AAjgg1mdxW+in0yRcV2ejuMMCOQcfSpB6gO/PcdKXW18klvF5quu9QQpGDnuOe3cV2b4oTtTr0zUeceLhIjhxzukEOnBypAB4HxVb8YwB9BvHx1iBb4aORWBpy97PIONuTngA/vS67ZbiIw3KIylTIY5CrKwZtufLIxj71KElJpo9PxyhH7Hj9pOEbaSMfJqzafDeXWw2tvNKSQPSpCg++5sD96s4TTLb/h2loig49EMS9fkCmNjPCwuZSmAVXylRR6RyCVDHnmuuVTdo5vvCNMyw0wWirLdMkt0jY2g5jhbGcD3PyftRslztBLsqrk98DHTvSu4vJwX2ejGMDB3N3zzx+lKrq/9LNJJzycn83/AO2sypaIqMpvY8fU4kY7fUR0x0+vNbXUVdSFIX5BHXrzVKbUwThNvfLSMFHv3qe2vmzmSWIA4wquuMdsc9anyaOtYL6Lit1JkDhueCD+3NFpMzg+n2HXjHSqtBfkN+UnoSBz+pFMrfUEO054O0DPc5PY01TFKEo+hwkwBxztAywPBPHQVMJFLYXPrDFSXBwBjHWlJvIS3DEbQo5Iz8j9aKhkjYQuzHG6JCS4UHzM8DI69f0+acIpEsl+w8O7DBXJwSR7jG6pw/DFQcrkfXgNkf60IlxbOEMskY2puVjkAupyAcD+rGB7UZEbBzvWRG3FSMgDKvJgYAx9P/mrLFfTIOf6jRljhlQMcBgWjPPcAnB6UasvlNDyGt5QThhk71O0gEdjwelRMNMeMQG6C+cCu8nJCueSC3ToMe2Piu1e1LIImglwDIgD7S2R6sZ+VIrXhfZN5E1VEjXDRSK8crEtCrqGJKMgYgA/IwR96meSKVorgYMJXEiE5wu7DH7dftQsvlZBaBgMlCY2zhjwcfqP+zUYngRQqwhVZjuMjEg5UZB/7/vWHCa0wSi9onkURmQoxZ0mPqyDlSDh2PxUUm+MzNHKm1fLATkls+o8ew70G97FbyLGSm3KxpjuuAemT06D6e9dpf2gunjD8zRvGCDmRAU4Zc9x/pUmpJ6KpJKyTNvIQwAUk59P5c/as5U8HI7c0NaSXht5P4h+GzHIsMLKyrJPtG0MUUkZbrn+2KWtq8O7yx3dkyM8nOBjFdMZp6MzxvtD3c68gkd8g4xW45C5bBbjqckZNLRfRmNAhDjLIcuHJK4B9QHX3ouG5tmGHIQqB1/tWrRC2gNJPM2qfKTrg4OcDnPFSXN2s9leWN2YniS3kmiMkxiZnUele+fgfFVKDUrkbQX4/KPbp3zXcsrSI5aTGM9ampUUUNg9oTJJKoGXLFgAP2GKfWyAoQM7xjBUffkVWIGKzM6nPlkFwOpX4q428lssAw/mTOF3lB6UBAPesJJqmdmV1TRJp1pe3TTSTlooo2Ea4XmXA6r3xTwQpGAqcD2PXJ+aUIZiGAO0HhewI+1GQenHPUdNxyR9aeKoaRy5W5h4KL6uvABB+a8p/wDECfyNXt4YeXayWQkjgBpHr1LzF5Vh9z1FeS+OZUk8S7RghLC0Q85xku/+tXlUjnjplVjt3Ztx3PKzKq9SzOTgAV6BZWv8MtEikkMl1J/NuJBg/wAxhjAI7Dp+/ekOiW8clxNMw9NlEZicHHmOdkfJ49z9qZ3eoW8a5eQDb7MBmpt+jsw4k/szu61KGHAlZUBO0s+5lXIzgKvJPsKHuLq1aCGWOUyCVGODCYWUqdvTJrUUuo36tHaaddSiQli8cW2PpgeuUbePrRNr4M1a7kEl/cpax8DyoCJpsexdsRj5wDUlG3o6MmSMWVue7UluRjPXIAAFBiC+vWZbW1u7glvSLeGSQEnsCox+9esWHhzw/pw/lWMbvja0t1/PkY98tJwPsKcLOI0CRKFVRwq4UDvwBxVlE5ZZb6R5fofhHVnma8v9PnjEJH4eGZMMzj1eYy57dh3+1WmXTtThQuLRiwwedpwffDHFWpLqRiN0hUe+ecdf1rsXtwN2ZgRnbjgjjiiWO/ZJSkvR5lNqV7p90ZZfNJOBKsrcuoPRfkdquen3VlqdvDLC4KuPS6gAhx1R17MO+aPvrPT9QjkW5tbVmIJ3eUFbnvlRVNitBod5LPYvKITgXdmTujkQf1Rk8hx1Bz8d658mJeykW3/Jb1tFGdrZPfeOP2pVq2+0CeYMh8qiQnJIY4ywPRfmmNtfRSwtOrI8JjDxkHl1PGSPfPBFA3sguYJC4/nDBx2VewGajJqG0eh8SUslqfRVLtpXlRohnarA7xlQ5yAygHt1GaJiub1fJK53IpAyN3PfINFx27OURI2dpGCKqKWYse2BzQ15f6ZpSSeePxNyEkCW8UmyGKQEAfipV698qp+/PF4uzOXWq2DarfC3h85nIUgooGcSSAcqmfbvVS/ETXMuZGOGbhV6AGotT1i41K7lnuGRi/pURJsihTtHDGvpCj2++SahgmCMjAjg9a3KBCGRVRZbGztnZVMUTEHqwDHB5+tWa10/QSYzLGsjYAf0bVHfgr+mKp8OoKpzGSrcbWBA5xTpNXvLl9Ljtb+PTrOHb+LgEJdbplPIbjncARgkDnPficonRy9x/wDhbYdI0bzHeKLZkjaAWBAx0zn9KrniOx13RttxbSx3elXUmz/eIkeW1nI/4bOgDYP9Jz2weRy6a+gSVhDKsiAjhWB6jPHvjvTi1ePU7G9tW9W5H2jg7XjAkjOPtzU4yp1ReeOcY87tI8th1DUZJWX8MivgZVGccHgYDE08t7nVI4ywScITkhSuemMgPj9jVjttEtZ7qzdVHnSrgEgYIBGQ2f2qfWEaDTdVESIZ7eP05H5HDhC/HsCTRCTbtks7jHUdsp8OtQPcmOS4ELCRSzStsWNhgevhvc5+lMn1K3hZUW8tHIEAUg7ldOSWDxlk+cZz8VS/4WxfcWcvncSVJYtnqc8U6g8O6hfiMtcvHENpZQoyGA25AHFWulohyv8AofSXk2CxjWVCVbfayLJGFCNyTHkjk5wQO/vUa6lsSEepZVLrIJTg8qFQqBg/tzioZfB2rWsSTQ3ZkGVAMe4OPqOv71NbaB4hdNvnQvHwBFdIZcKOhBYZH2NNOX4JvGlZMupXBIQTqDnnEpBJPoHetC8cqzmRNwbq0rNuweCB+lLNR8Oa5aK82y2IAyBFM6n3wEZef1qtJLrcsjQIq4VjuZztRfqTz+laal7CM8b/AJLbcXhLI4l/IzMArHGO4x1qC61iNbm3uGlOYBH69wUsEHYn44FcaZ4cv74KZ7shD/5aFEBzkkMcsauWm+BvDERRrkG7kAGDOzeWT8Kp5P1rMU27FPJCKplBu/El1OHWztZpr58rH5SO5RDxvZUBGTUFppnj6Qhxpdzk8/zisRz1/rOa9ytdK0mzULa2kEKjoIkAz/mI61LLLFGCiKrMDyNvC555J/61dRpbOKWa3o8strDx0BH+JsI1wQdrThCfnkYo0zarbnbc6bdBiOPLVZgfuhq+vuYEs27jkew7YFINU8QaJpUscFzcRiVk3GJUaaSMezhOn3pKDZOeVLtHm6MQASwA+ePsaLSQkgKWY88AA8UqikEvqjcEEdDjJH261IkxiYugK7evOR9BUno6o7YV5nlXCk8BhgkccA+1XSyaEqqLwwjUkDBzn3Y15xdXju6yMoVF6qingE8/Oas+i6wkXmbwJS0aiJfUfMcflJK88VnG1dM6smNuNlujyoK8Fj/jbJHPY1224NH6h6lIXJyCy84DCk51i1TUP4b+Ka4uFjLyxtbiOEOFBcQSgfmQkEjGOtEyXKKAztjBYnJAHA5NUut0cqi31sJuLsqhbOMEA5PT3zXm2rWuoa14iuV0+F7iXZAHC4CxqAU3SyH0r9zV/SD8cSruVt2YMjp6WkHxkfvTeztLa2TyIIUjTlsIOWboWY9SfrTVt2SnSVFV0nwvNZW0tveXAaS6lEkwtNyqgRMKnmOMnv2FPbTQ9Hsh5q2MW5hgSSDzJCwGT6nyf0pr5yIxBHIAIyMDjpkd6Hllx35AyCT75Gaa49tiufRosowNoBHQDjbjj9a4eT/EAo3A5PHA+KHaY4JzgBsZ6e/3oZ7hAxKgyuMgn+kfPNLkvRpQ/QouW8wD1YO3jOP0qNp0Bbc4UAEcDOD15ApfJNJ6vWACC/oJCrk9DS6W7CZw2CB29jTborDHyG5vY43GBuXOec4B+cV0NSmOQhVAc52gDrx9ar34uIepmbBGc7TyB1wTxQN1rQUiKLJYgnESlmwevOKg5s64YUWS91+4tQdlwDKRgZ5YcAAn4qoXepySszPOzyMeT3LHjFZPp+uXBHlW8SRvgmaaQMeRknapz+tTWWhfh5I5rmR55c4XK4t1bAOSuMnGeuP/AGPvPsaeKCpdh2kyTWVvO08nlRmTzSZ5AsaZXac7sKD96sdtELlEmWRGVwpBQ53q3ORSx7K0eOQ3KiXB9C4DINpDYO8kcj4oixbbE8MeMxKrDbwNrchRjA4qeTHSv2OGa5VDSJdXguobS4XTlkTCOHCsBcXIP9LOMYGOw4981Rz4eudSeMyzNGmMY3FyD0CBTxmrhdXk2xskAg4I54HxQkc5JDLwwPB/0xUo51FnXL408kaQji8GaUv/ABrud2AIKrtXB+eKkHg7R9pImuzhgpJdRz1wMD25q1W00BIE6AA4ywHH3ozyIs7lAw3TYBhugyfmulZfJ/LPLnhlhdZIlOHge2mIEF3cRAgcyFWyST2x/rQtx4P1myZDDdwSqxIj8wtGXOcYUjIz9cdav4jdpRHGE3bSJPWF2Z4UMze/+lEzxRJZJO0ZcrIVk34EyhWxvUjoAeoP+tUb9MmsjT0eXyG/srmSxuYGW7hCBliLOOQHDAxg9qtnhWXW1vkC2V0YypBkuIpYoE5ByzuB9sZpwLZJp5rwMcEQyI5OPMib0Y29sEH7U3TU0ciKGzvJ0RA6zoYlhYDK+nzGz14qSxJu7pHfL/JPx+PjYOLu00oXN1eHy0hxGvJyzSH8kYP9R7fBJ7UmvtWhle6guLe8LXFtIzzIgMUvnSIixQhTnCAjk9gT2qo+ItV8QT6qYdWtVt7YPu09ITmPbgLnzceonGTnkEcYBwWej326IQ7zhDwrHjFKSqo9kYR8n/JQytbRJEVDHnBI9Q7duasNjZJFIqqmQQMj/Fx/STUNpEYVE00Um2ZCYsjtnO9s8ge3FPV/l+XO3ofyyFU4AQNj1HHx0rcY0qs58tJ3RBbwyAKVm81XmYIXAUBc/lO0dulZdXdnZbkfLS7d21WUKikZ3u3YfX9KXanr9vbboIWVfLBk8xh/wznLSBR7noKqUks2qTCZ2lRFxIhnJYOzt+Z1XjJ+c1VzUVRBY3Pb0gvUrrWNVZreCVIrYnDS4bDgngKvDY+aK0zQdLtQPOlh8w9RGmSSe+OWrVtDdI4V2B442AEEe4OM07ijVGVnQDICvtwQTxzn+9S5Smyq4xVIlRbaJjEkTRlCNzOdrKD3cAcCpVIWf0yBkfptj4Zff6H6VMIi7ROsso8oFY9rDO084AOTW0jjEhw7Fjk4dmwcHOAO3XpitVJdsxyRMs7ZGZBHGAFYkk7WHABYAZHtxRDJHGjEPyOSCftgZ5qCSaONQUKMSecjAO7qcGhpZHaOV9y7lR33kjagVScsTxgVZSs52q2SX+o2WnWkl7dOqQxrwpPrlk6iKJe5NeLahdrNdXF5KC0t7LJcsCQWUM3AJ+On2o7Xdan8QX6yDeLS3IisYicYQDBkIH9TdT+nahobOK5hS4wXWQsoYkgeg7dvA6jv9a1dOyLTkVOC8mgIIxgdgcZ+tOYr+B0G1lPILjndz1Iz1pO0BwVATJ7gHNRmKWPaSM5IAwe/vxQ4JloZXHotEK+aH2gEknPGQR1rmBZLOVndisARzG2ZFUOSMBjH69vvioNOuNsKg/nRmVucgkHIJzU8kjyssQJJkfaAACzO3RR9a5HDZ6OPNcaHsd9pk9z+MRDJqEkaxo6GTy1LKvmGONznccY6VarSyJ8qW8D7mIItwudhI6yds+wpJoOi2+mhbmTa94RjcfUkAPJWIe/uf+zZVuI1IdpI14By/pAGO/aqqvZmdpaCo1Dt6wN5LKo6bcdjW7a6dJREdp9RCZ6/OaCluZAPMDBt2ZFbsVGcEH5waVPqDNNFKrBWjlV2AwQVHJUZ96fuyHHkPJnla4aQH0gnYDnOcYOT+uKGuDcKWAUZKh+WwMEZ6kVptRjkmlYHKOcqxIUr0IwBxmo7i905EkknebcHGIl25ZeOhPOf9KXGG9lLnpEUqYLGadTk8KmckY75oN5YoztTccerdIQBgDPQcUBLqEr4MaKrnK7mJkY56DHAqUaRNeQ+ZLM+GDBQQdpfrg47fapuk9FlaX2YBd6qiM6RyA5XBCAkknqqgUKq6hcLKwhkTrjzFOTjuR2qwWuh2dod0eXYqpLSLtOehwPbmjYYrEXElkrebdxwxzzqc4RJCQoYjjPFDi32HmjDSQkbT/xUEcUksxjWW3dY/wCcWwsZVg7sdvXsoAximMWl28JCpCFGAMgDp9SM0/ityMYCrwABjj96zyT13Dkc8dqboh5G/YvW22ghQB75/eofw4VlfGCvfv8AamvksQSOQST16CoZIsE9DwPmhv8ADHIVrDxsHC7yxGT360UscduQx6uwQZ6H/l44qXyxntjnpXZUEpuRSc7k3c7SOhFZds0pUK9Vt3jZJohmOQ49wDQ9tafiY9yRsuCytv4wynoKsLKJQYmAw2SvbBrdrFHDvXHVyc/PTFcfgudfp6y+bxxWu0IzZXqgAFPb1ckCiIkubV4pN8jQkZISMly4HMQHIBJ6H5py+wyr6FYYwAxONx4BbtippFiG7MeC3pcFdjSFP/qqAMAjp81X/V12Rf8AkZSXGS0BWaQXb3PnynbG6GaBJGJjux0KScEjBw1FzwRPKvBOE2gMSecYJbt8VwkUbusw4ljyV4AG49QwGOvf/wBqln/mqZF3KWAYgHIR+61XFBrUv/TOHLOLdw6NxxxofKKkBx5XyAVAAH0ri6H8OgeaO4ENvBEqSSnIdYQRkBufV1A45rEkd0Byc8YLcZ46n9qiv4pr3aZJo1h4WS38rJaQNu3b936DHFVk1WkZjHatiSDT7i+Jg1JHuLe5Ezxq6ZMcWd6MxXkOeNvfP0qv6jbXHhC5veBNK6l9KkkXOAwyZGU+ksh4x34NejrI0aRbmYFkO4qMZ245IHtkUo8TaR/G9Cv1j9VzZobuxlHDiRMloi3swyKy8aluzojlePSWjvQ5Y7DRba41G8a4vrofjbua6mDHzZPVtLOeFXgBR7dOarviDxvaWxeKCQXE+M5RsopI9x3rzGTU9Ukj8mS5laNeNrEHHagic5PcmupQPPnkt2i/6XqF3fw3d0fK/E3DlbcSASLFHEQSxUjBLHPX26U2szqB3CeVmVmDGMHILAnpgAY79OKpeiz7Vt4wxBEhUgZ/qJNX2xgmlVXyQNwAPc+/Fc0lTZ6OJfRSY9gTzYiVUq5TCCRmKq2B6crzz2pkqb1G2QFXYKSB6SQDuHPzUFgqxIokfKgkscgNx/h7ZqWXUNNto2M3lKoGRuOUHPJx0+vNOMH3I5Z5Eug6AMY18xgMLgtjGWHTAFZLMuw+WAG3bxJJgyHjGT81WD4v0GRo0gnNxNKwjjjhXczSHPAA47HvVb1rxrOr/h7UeU0cmJjE0cs5HGV80boV+2+ujjZyuey9TTW9svn3cqJGSq5O4mRjwFjQAszHsADmqf4l8UfiYptMtSYt58qaNNplKdW/EyIxC+wRST/iI/LVPm1bVNSm3RvJCTGYsrNPJMVbIIeeVi/PQ42/SjLawjghTC5b1M5Ub29K9FX+9ShiUH2E5uSI2U2yR4wHcb1AYBsZxkDrUaNHHuzFMNx3Eb22k/4gDgftUMk7Ss0p9UucZ5IWNeAm0jH05rHnZgv++ZA4VcSjZ3ICNkAfQ1WyaFh4HOfb/s1rjHAbr85xXZye3Oc8/NZtJI54C5IU1UmdQNtc5PDnBXuPY8U70u5trW7aaVRvjgcW5c8I7EDdj3xnH1pIGjGGVDwMe5z9BW/Nd+rBcflOMgY7MKjOLZ1YZqL2X5dbsSAI2LsB6FA2qGxgA5OcVDd3moTvZQ2N0kaekzvIUDtcZy7OCCSgHQD/AOKHJcSruUqARyrIeCD9f+tRvfSsoUGYYxgNJwMjB7ZrHB9nTLNBo9M1PWNLCy28MoVYJcbYzncWUbwpBxjPakkmpKSFj/OwAI6/QECqhZi6uWcIdqgjfIeVQe3uTTkzW1mFRS27ALO3LYxwWI/asSUrL4ZwUR3+Pf0qyqCAcnqfsOlcCcEkkDc2Tzy3PPJNJop3nIaP8h43NnGR7ZphBbOzjAJLYyTn9qXFl/LjrsMikIkztyffvj7VY9OvJ/QuAU9jySM5waq732mWJInnWSReDFbYlcEdiQdg+5pfP4nuXEgswlnGv5pUPm3JXoFDEbR9QKax7tnHkzLpHoWoahY2katPPBbNJyolcAkdyAeaFh8R+HFZma9t/MIyZCygnPTJryuPzr2dp55JJSTy8zNIx+pbms1JoogLeNAJCAZW9h2UfPvVa3o5HpHtVtrOmXCqY7iJt3AKupH2xRX4iJjhWB6fNfP1vdXlo2+3ldD3A5U/BB4q16f4wv41C3KMQoGBGobJHchyCB9GrTiyXJnqxlTDfA68VBvSUsFxkDJHcCqPH4zsXGJRMuTzujYDn/KTRcXi3RI2dvPbL7P/AKcnBAxkZFZ4NjWQt4i5GSOv/fWtt5EQByDwM455HGCTVSm8aaKwA86U4I/LG/OPrQk3jPT3XCGbo3YrnPHtS4GvIXQyxlsjIJx+b56c115sSn8w9XIAIIzXn8/iixUqY7qVyVUnZG67TjBHNCf7TWbt65Z8dtyN/wBay4tbo0prqz0ZrlA8hfG0Dr0GPvUa3qBixYY5wxP6faqD/tFpZBGZmwMnbGx4H1Ncp4ksgCY4LmQDON4VFP7n+1YfN6o1cf09IS7iXLySxFCC2VZTgDgnrQR1a2eT+Uy5kLDjKhmAwGJPevOLjxLI7gi2WOEBsqCWY8ezYFLP4prk+AJzGrcYgRUznsG6/vVeNrZjkeqpqlvbuCXyCo3IDuKL7HFTPqunsMpMhHPDE5H0OBXjt2b6BVV7m4aaT1kGVjhBxk80GJLw9Z5s/Mj/APWt8NGeZ7U2t2CIWMo78k4Hx17UKfHPh6yWU3EwmKxttgthvkeQA7VyPSM98npXkREkgHmF2PuzsePo1aEWeAMFhjaccjrnms8F7KeV1oglfzZJJNoXe7vtXhV3HOB8ViQzORtU89OKZQ2sCqGYq7jkJvQZ7YOTUd1LdxloPJFv/iA5cj/P7fSqdEuzLKdrC4DMVY7GA2ENsZhjJHxV2j8V6YkaCLcFUBQu1hgD34/1rzsoRjHtUqq5wCxwB6QOn7VhwTfIqssuPFnoI8Y28jRIGSNZJCjzz+Z5cKbc7zHEDIfbgfpVb1PXbm6lkCt58eJY0a4TbAFcFA0duSQD3BYsR8UojiGAepH1qYW7v0HTr7VtUiDk2DoHYtuYkMfUM8E+5UcUbFaPL5YHz0HQfNE21nCuTKexxtxgHHGSe1TPdQKD5WNyIeUHpz0wSKLMkgEVkuXAVwMkcA57BRmgprm4lY5OFIIAU9Ae+eufeoHkklYvIxZzwSfb2HxWccYrCVGmb3KoIO48564XPvipUlAGAf8A7Qf70O/X7fatr/3imI2RntjAyR7fOa0oznjP0P712DjHA49q2Qwy2DyeARxiqGCPn7g1rHBUjhuRnsfeuiQeNoAJrCjcHGeP6SDigfREYs9ckcdOcEmujBCAC0ZfJBLYO1R3GB3rvaygZPY4+9SI+NxYHJAAI4zWWvw0pG4rlbULGUJwSdqEKBnpggGpBeWxBd7VmfI275fSMcf4ahZfMJJPJH39u9R+USwAz26dqOjfJv2HpqbIy7YLdFBGWIeRgPq3H7V3e3F4WjmkebyGYosTo0K/lz+UHODmgfJkDKFUkoQcquRkHIIqabMoUNEikyNM/lptLSNwWJyTzRYgV2D4UpGsYHCRqFUZOc8c1JGmyGaMAbZWUtnGDt6c/FaMftzk557fGK1wvbP64NJ7Gm0SPMIYhFAmDjmQdQP+UUA0bOSWOSeeeT+tG5L8DcD0Pp45+tbUAEKwBJ6H5FBiTbA1gPBCgk8DNTpAMZ7dPv7UcigfmHyOMfesOwEZbA5PGMH9KLM02CCAdcZ46Z5rXlqTjB47UYvlEgZXPywHP3rnYpJA2kjgbSMZ+tFjoF/Dg5O0n3HYfPFdHT2MEkw3elS2DG2w4cJhZCeTz7UQRtJDMV4wwGfvmujcExCMLE38ryfMKnzBEG3BQc8c/FOwoXG3Y9F4Axkc1H5Sg4x8f/NHjeAAGPPbtj61sRKd3GSx9+lJsYCI0Hx3yOKnaY+lUwECgAYHWpTAh45B4xXIgwSOv7YpdjTroFaPcdxGQOOfnrRCSxpGgWMtKOrPwigdAoHP1qURBsDA44zjnFaMIBbHGOvXqfk1qxbYG4eR3dyWdjznvxjitrFJx0olYwf8oPAPWunIAU8D4+9KwoFMbDrjp0xRdjZLNIWk3hEAJ2xl+WO0bjkAD/vtUbzQKRncT3A5xXK3kgDLsQxGRJFSRd4Vkztccjnk9felZqqAjGfNaM7VYOyE84GDisYOzENliuBy2Rge1TEb5HY49TlzxxljntXSoecDnv70DIlQEjB/9WMfWpVVM8DJzzgZH14qWO3LEFshcHPUUSI4olwuct1bnueOBSugOFUKvKjP2zWGV8YVce2RyDUiLjaz5ZSQGEeN+O+N3GftXOEXfhQMknB5O3OcE0WYIHMpUK7MPVnnhRge1cEY27enGBn96J8mSUXDruYRxiV+N2BkDJPbFRFRjdu9j3yQe4pgRqDz71sHJAz3xz+lbHGfvmuVYqyMOqMGB9iDkUAT3Ns0Ijb14csoWSMxnKAHJDEnBzxQ44qaWZpl27IlHmPKViUqTI+AzMSSecVCcjHTp+n1oAJMbcEED34/tXXlnJwfT7E0wuNJ1OKzurrdYt+HtluZ4be/tZ7u2hfCrLNBExYDJAPXGRmmGqaME1bWbayextbOxktY9+pahBbIGmgSQKr3DbmOck8cV18ImSvGInHPfpgYx8VoxNkYK4H1pymga07XivFbW4srtbG7e+vLa2iiuGQOqFpG53AjaRkHP3rqbw9rtuH8+G2jeOe2t7iL8batPbNcyiCF7mNGO1GJGCT3B70+EBiXy2GT6cnr7VyIW3AlhtJzgZ/amL6fqEf8WLxBBpU0VtfbnUGOaWRoljUf1HKk8dhmtppt81kdRP4WO2KzvCLi7ghuLlYG8uRreByHYKeCR7H2o4RFQuMTZzuHHTrwPis8uQflbvnn29hVgu/Deo29xZ28M1lcGbTINTnlF3bJBaxuiM7TyFtqoCwEbH83YccC/wAE1j8S1r5MGUtUv3uDdW4sBZudqz/iy3llCcgc5yCMcUuEAFqGZcnzDyOcHFaIcnOEPySc09GhztYxxxRJcavNr/8ADIRZ3Mc8EkBsEu/S6Hy8DO52zwAc9KX22n317dTWdokU1xHHPKdk8KxskBAd1lkZUKjrnPTmjxxYwNQVbdhcnrxmuGi3HOQOcn5NWTT/AA9dPczwXcUUom0HVr/TZbS8he1luLYoikXKMI8KSQ4JHz8hHQ9Y/EQ26x2r+daPfrcxXlu1iLSNtjzvdBvLCg+k989qXCA7FREm3aNo+aiEMoK+peMnvVig8OajKdU86ewgFnpi6nBI95bm3u43lWNWjm3bfL67m7EAYy1DfwTWBbNdGGEKtqL5rf8AFQG/S0bBFw9pu8wJggn65xR44MViorIVI3AtjbnJ4X2xUfkEjliG5wR0qf8A761lPwxHyZEII9pDZJyCDn2rn8OFbdGxU/8AfPFT1lHhiLkyPZJtwWBJGCSTnNa8uUA4ZeuRxjmpayjwxDkzgKx/MQTXQ3jOSMdvet1lHhiPkZznPzW/SRz1xzj3+tarKPDEVmgHDZyMdwO4+tak3sFAC4XGAxJ4/SuqyjwxDkzkq/GNvHyf+lReXcB/MEgLcY3Z2jHxip6yjxRHyYGbWbJYshYkkk55JOc1sWsn+JOue9F1lHiiHJg4tmBB3r1z3qVYyMkkZOe3eu6yjxRFZoBlOVdh/iBwQcjng1mHzj07fbkGt1lPxRCzZyRgkYHxWgFJGc7TncBjJ+mc1lZS8MQs5ZCVABGdpU/08njHB6VJOxljVDsyuza4QKwCqE2Er2+1c0TaWk148yRFA0URnYybgCgIUgEA8+w79ulHiiAv8lvVyOenXP3rXkNx6h+/H0p7/A78uqCW3O9FdSxdD6mlUb0cblHoPJHUgdTXMuj3kVubrzIWjEMlwVHmLII0CAuUZc4ywXn/AFpeOICbyXOASNucnH5q20GcYI4GOnXHfipa2KfhiFlsvNT8PLY69badcQxWt9oz2Wn6dBpCwSW8uYn/AN7vTmRmJU87iDkk4wM5Pqeg3F54huorqC1urq8tZLa+u9JGos1lHaJE8FvDMCqPvBOSBnjkY4qdbrXBAWPxDq+m6lb6+ls8jPfa/ZajAJYmQmCPTBasW7AhuMZ/ao9Q1LTbm78fyRPIy62lpHYbYpN8hS7ilbKgbgcA449qr+K2CylWVirKQyspwVYHIKkdx2p8UBZvE14zW+lWstu1vqF3Fbazr0b/APE/HtbR2sQkXqrbFLlT0Mh7mhrO809NHuLa+vo7pPwt6tppkmnMZrS9mJ8ue2vifSvRnwwzyNpzmkbs8jvJI7PJIxeR3Ys7sTkszNySe9c4o46oC0NqGi3FqbZ79oRqGgaLps5NnM4sbrSShXzQh9Ucnq/KcjA4rP4johsH0D8bItqNLtLaPVGtJSr3UF9JfHfbqfN8k79q9xjOKq+KyjgBaLHU9F0zT7vSRdyXlvf6hKl5cW9tLazJZz2aRNLbGQlgVcYZT+ZcjHOKE8PxW/8AFNZh/E7rYeH/ABHEbqOB+YPIC+cISQ3TkLke1IsV2kksRcxyOheN4nKMVLRuMMjY/pPcUcQLJb6jothZfwyO8e6RNF8Sxm5W2liilvdVMHlwxRP6wqhDlj3P6x22paU2k2mkz3Dw+dpF7ZXFwLd5Ra3H8VOoQ7kXBZGHDbc44+1cx8msxRxAsq3uhi2bRvx7/hh4ev8ASxqLWc3ltdXV+l+xEAJlEYxtU4z3x7yS6loj3954gF5Kby40uW1XTPwkgZbqazWxYvcE+UYhjcMYPbHFVas/60cUBzjAA9gB+grdbwKzArQjVZW8CswKYGqyt4FZgUAarK3gVmBQBqsreBWYFAGqyt4FZgUAarK3gVmBQBqsreBWYFAGqyt4FZgUAarK3gVmBQBqi7SyN2tw34q1gEGwt+JcqX35xsA69Of/AHoXArMCkAxn0l4Y5HF9p8rJJFHsgmDMzSEYIzgYGQSf+lStorpn/wDMbIBPL3kPnlzgbVVs5GR+/tSnA9h+grNo9h+go2MYPp04eIfi4GWeGWYSB2wY4m2YIY55IbHJ4Unt6sn05oo5JHv7V3RNwiVmZ3HIwDkjPGR7gg8ZwADzjPOMAZ5wB2FawPYUUBqsFbwK7jQuSAccZ5oA/9k=',
                          ).image,
                        ),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 3.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 2.0),
                          )
                        ],
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 120.0, 0.0, 0.0),
                        child: Container(
                          width: 100.0,
                          height: 100.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(8.0),
                              bottomRight: Radius.circular(8.0),
                              topLeft: Radius.circular(0.0),
                              topRight: Radius.circular(0.0),
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                16.0, 0.0, 16.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '11/03/23',
                                        style: FlutterFlowTheme.of(context)
                                            .title2
                                            .override(
                                              fontFamily: 'Lexend Deca',
                                              color: Color(0xFF090F13),
                                              fontSize: 22.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      Text(
                                        'Highest bid: 30k',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyText1
                                            .override(
                                              fontFamily: 'Lexend Deca',
                                              color: Color(0xFF39D2C0),
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    FFButtonWidget(
                                      onPressed: () {
                                        print('Button-Reserve pressed ...');
                                      },
                                      text: 'Estimate',
                                      icon: Icon(
                                        Icons.add_rounded,
                                        color: Colors.white,
                                        size: 15.0,
                                      ),
                                      options: FFButtonOptions(
                                        width: 120.0,
                                        height: 40.0,
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 0.0, 0.0),
                                        iconPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: Color(0xFF39D2C0),
                                        textStyle: GoogleFonts.getFont(
                                          'Lexend Deca',
                                          color: Colors.white,
                                          fontSize: 14.0,
                                        ),
                                        elevation: 3.0,
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 8.0, 16.0, 0.0),
                    child: Container(
                      width: double.infinity,
                      height: 200.0,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        image: DecorationImage(
                          fit: BoxFit.fitWidth,
                          image: Image.network(
                            'https://th.bing.com/th/id/OIP.-ELv9-jDa0V18Jrq5AkqiwHaFj?w=268&h=201&c=7&r=0&o=5&dpr=1.5&pid=1.7',
                          ).image,
                        ),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 3.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 2.0),
                          )
                        ],
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 120.0, 0.0, 0.0),
                        child: Container(
                          width: 100.0,
                          height: 100.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(8.0),
                              bottomRight: Radius.circular(8.0),
                              topLeft: Radius.circular(0.0),
                              topRight: Radius.circular(0.0),
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                16.0, 0.0, 16.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '10/03/23',
                                        style: FlutterFlowTheme.of(context)
                                            .title2
                                            .override(
                                              fontFamily: 'Lexend Deca',
                                              color: Color(0xFF090F13),
                                              fontSize: 22.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      Text(
                                        'Highest Bid: 27K',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyText1
                                            .override(
                                              fontFamily: 'Lexend Deca',
                                              color: Color(0xFF39D2C0),
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        FFButtonWidget(
                                          onPressed: () {
                                            print('Button-Reserve pressed ...');
                                          },
                                          text: 'Estimate',
                                          icon: Icon(
                                            Icons.add_rounded,
                                            color: Colors.white,
                                            size: 15.0,
                                          ),
                                          options: FFButtonOptions(
                                            width: 120.0,
                                            height: 40.0,
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 0.0, 0.0),
                                            iconPadding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 0.0, 0.0),
                                            color: Color(0xFF39D2C0),
                                            textStyle: GoogleFonts.getFont(
                                              'Lexend Deca',
                                              color: Colors.white,
                                              fontSize: 14.0,
                                            ),
                                            elevation: 3.0,
                                            borderSide: BorderSide(
                                              color: Colors.transparent,
                                              width: 1.0,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 8.0, 16.0, 0.0),
                    child: Container(
                      width: double.infinity,
                      height: 200.0,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        image: DecorationImage(
                          fit: BoxFit.fitWidth,
                          image: Image.network(
                            'https://imgmedia.lbb.in/media/2020/04/5e9841d8226fec213ee10de4_1587036632035.jpg',
                          ).image,
                        ),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 3.0,
                            color: Color(0x33000000),
                            offset: Offset(0.0, 2.0),
                          )
                        ],
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 120.0, 0.0, 0.0),
                        child: Container(
                          width: 100.0,
                          height: 100.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(8.0),
                              bottomRight: Radius.circular(8.0),
                              topLeft: Radius.circular(0.0),
                              topRight: Radius.circular(0.0),
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                16.0, 0.0, 16.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '9/03/2023',
                                        style: FlutterFlowTheme.of(context)
                                            .title2
                                            .override(
                                              fontFamily: 'Lexend Deca',
                                              color: Color(0xFF090F13),
                                              fontSize: 22.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      Text(
                                        'Highest Bid: 28k',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyText1
                                            .override(
                                              fontFamily: 'Lexend Deca',
                                              color: Color(0xFF39D2C0),
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    FFButtonWidget(
                                      onPressed: () {
                                        print('Button-Reserve pressed ...');
                                      },
                                      text: 'Estimate',
                                      icon: Icon(
                                        Icons.add_rounded,
                                        color: Colors.white,
                                        size: 15.0,
                                      ),
                                      options: FFButtonOptions(
                                        width: 120.0,
                                        height: 40.0,
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 0.0, 0.0),
                                        iconPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: Color(0xFF39D2C0),
                                        textStyle: GoogleFonts.getFont(
                                          'Lexend Deca',
                                          color: Colors.white,
                                          fontSize: 14.0,
                                        ),
                                        elevation: 3.0,
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
